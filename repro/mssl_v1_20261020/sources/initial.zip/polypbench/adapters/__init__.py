"""Native model entry points."""
